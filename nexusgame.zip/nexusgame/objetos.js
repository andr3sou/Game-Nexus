// ================================================================
//  Objetos da sala
//  x, y = posição | w, h = largura e altura (sala de 960 x 640)
//  parede: true = pendurado na parede de cima
//  z = ordem de desenho (opcional, para objetos em cima de mesas)
// ================================================================

const OBJETOS = [
  // Parede
  { tipo: 'porta',      parede: true, x: 48,  y: 22, w: 64,  h: 74 },
  { tipo: 'calendario', parede: true, x: 170, y: 30, w: 50,  h: 52 },
  { tipo: 'quadro',     parede: true, x: 280, y: 22, w: 260, h: 62 },
  { tipo: 'espelho',    parede: true, x: 590, y: 16, w: 46,  h: 72 },
  { tipo: 'janela',     parede: true, x: 680, y: 24, w: 120, h: 56 },
  { tipo: 'poster',     parede: true, x: 846, y: 26, w: 56,  h: 64 },

  // Móveis
  { tipo: 'estante', x: 26,  y: 250, w: 50, h: 140 },
  { tipo: 'arquivo', x: 882, y: 260, w: 52, h: 108 },

  // Mesas com computadores
  { tipo: 'mesa', x: 100, y: 190, w: 210, h: 46 },
  { tipo: 'mesa', x: 650, y: 190, w: 210, h: 46 },
  { tipo: 'mesa', x: 100, y: 440, w: 210, h: 46 },
  { tipo: 'mesa', x: 650, y: 440, w: 210, h: 46 },

  // Mesa da NEXUS (centro)
  { tipo: 'nexus', x: 400, y: 300, w: 160, h: 50 },

  // Objetos soltos
  { tipo: 'caderno', x: 176, y: 452, w: 34, h: 22, z: 487 },
  { tipo: 'cadeira', x: 362, y: 318, w: 30, h: 28 },
  { tipo: 'lixeira', x: 578, y: 318, w: 24, h: 28 },
  { tipo: 'planta',  x: 34,  y: 560, w: 40, h: 46 },
  { tipo: 'mochila', x: 760, y: 566, w: 42, h: 34 }
];
