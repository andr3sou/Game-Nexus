// ================================================================
// PERSONAGEM — PROTOCOLO NEXUS
// Anda nas quatro direções e colide com os objetos da sala.
// ================================================================

// x e y representam a posição dos pés do personagem.
const jogador = {
    tipo: "jogador",
    x: 480,
    y: 540,
    h: 0,

    vel: 2.4,

    dir: "baixo",

    andando: false,
    frame: 0,
    tempo: 0
};

const PES = {
    w: 20,
    h: 10
};

const LIMITE = {
    x1: 24,
    x2: 936,
    y1: 96,
    y2: 616
};

const SEM_COLISAO = ["caderno"];

// ================================================================
// TECLADO
// ================================================================

const teclas = {};

addEventListener("keydown", function (e) {
    // Depois do fim do jogo, ignora os comandos do personagem.
    if (window.jogoEncerrado) {
        e.preventDefault();
        return;
    }

    const tecla = e.key.toLowerCase();

    if (tecla.startsWith("arrow")) {
        e.preventDefault();
    }

    teclas[tecla] = true;
});

addEventListener("keyup", function (e) {
    teclas[e.key.toLowerCase()] = false;
});

// Limpa as teclas quando a janela perde o foco.
addEventListener("blur", function () {
    for (const tecla in teclas) {
        teclas[tecla] = false;
    }
});

// ================================================================
// COLISÕES
// ================================================================

function sobrepoe(a, b) {
    return (
        a.x < b.x + b.w &&
        a.x + a.w > b.x &&
        a.y < b.y + b.h &&
        a.y + a.h > b.y
    );
}

function bateu(x, y) {
    const pes = {
        x: x - PES.w / 2,
        y: y - PES.h,
        w: PES.w,
        h: PES.h
    };

    // Impede o personagem de atravessar os limites da sala.
    if (pes.x < LIMITE.x1 || pes.x + pes.w > LIMITE.x2) {
        return true;
    }

    if (pes.y < LIMITE.y1 || y > LIMITE.y2) {
        return true;
    }

    // Verifica colisão com os objetos.
    return OBJETOS.some(function (o) {
        return (
            !o.parede &&
            !SEM_COLISAO.includes(o.tipo) &&
            sobrepoe(pes, o)
        );
    });
}

// Move um eixo de cada vez.
function mover(dx, dy) {
    // Segurança adicional: não move após o fim do jogo.
    if (window.jogoEncerrado || window.portaDigitando) {
        return;
    }

    if (!bateu(jogador.x + dx, jogador.y)) {
        jogador.x += dx;
    }

    if (!bateu(jogador.x, jogador.y + dy)) {
        jogador.y += dy;
    }
}

// ================================================================
// ATUALIZAÇÃO DO PERSONAGEM
// ================================================================

let ultimoTempo = 0;

function atualizarJogador(t) {
    // Congela a movimentação durante o fim de jogo ou ao digitar o código.
    if (window.jogoEncerrado || window.portaDigitando) {
        jogador.andando = false;

        for (const tecla in teclas) {
            teclas[tecla] = false;
        }

        return;
    }

    // Mantém a velocidade consistente entre taxas de atualização.
    const dt = ultimoTempo
        ? Math.min((t - ultimoTempo) / 16.667, 3)
        : 1;

    ultimoTempo = t;

    let dx = 0;
    let dy = 0;

    if (teclas["arrowleft"] || teclas["a"]) {
        dx -= 1;
    }

    if (teclas["arrowright"] || teclas["d"]) {
        dx += 1;
    }

    if (teclas["arrowup"] || teclas["w"]) {
        dy -= 1;
    }

    if (teclas["arrowdown"] || teclas["s"]) {
        dy += 1;
    }

    jogador.andando = dx !== 0 || dy !== 0;

    if (!jogador.andando) {
        jogador.frame = 0;
        jogador.tempo = 0;
        return;
    }

    // Define a direção do personagem.
    if (dx < 0) {
        jogador.dir = "esquerda";
    } else if (dx > 0) {
        jogador.dir = "direita";
    } else if (dy < 0) {
        jogador.dir = "cima";
    } else {
        jogador.dir = "baixo";
    }

    // Divide pela norma para não andar mais rápido na diagonal.
    const norma = Math.hypot(dx, dy);
    const passo = jogador.vel * dt;

    mover(
        (dx / norma) * passo,
        (dy / norma) * passo
    );

    // Animação da caminhada.
    jogador.tempo += dt;
    jogador.frame = Math.floor(jogador.tempo / 7) % 4;
}

// ================================================================
// DESENHO DO PERSONAGEM
// ================================================================

const COR = {
    pele: "#e0b48c",
    cabelo: "#2b1d14",
    camisa: "#3b6ea5",
    camisaEscura: "#2f5885",
    calca: "#2a2f3a",
    calcaEscura: "#1f232c",
    sapato: "#14171c",
    olho: "#111111",
    cracha: "#e8e2d0"
};

function desenharJogador(j) {
    const passo = j.andando
        ? [0, 1, 0, -1][j.frame]
        : 0;

    const sobe = passo !== 0 ? -1 : 0;

    ctx.save();

    ctx.translate(
        Math.round(j.x),
        Math.round(j.y)
    );

    // Sombra.
    ctx.fillStyle = "rgba(0,0,0,.25)";
    ctx.beginPath();
    ctx.ellipse(0, -1, 11, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Espelha o desenho quando anda para a esquerda.
    if (j.dir === "esquerda") {
        ctx.scale(-1, 1);
    }

    if (j.dir === "baixo") {
        desenharFrente(passo, sobe);
    } else if (j.dir === "cima") {
        desenharCostas(passo, sobe);
    } else {
        desenharLado(passo, sobe);
    }

    ctx.restore();
}

function desenharPernasFrenteCostas(passo) {
    const levantaE = passo > 0 ? 3 : 0;
    const levantaD = passo < 0 ? 3 : 0;

    R(COR.calca, -7, -14, 6, 14 - levantaE);
    R(COR.calca, 1, -14, 6, 14 - levantaD);

    R(COR.sapato, -7, -3 - levantaE, 6, 3);
    R(COR.sapato, 1, -3 - levantaD, 6, 3);
}

function desenharFrente(passo, sobe) {
    desenharPernasFrenteCostas(passo);

    ctx.translate(0, sobe);

    // Braços.
    R(COR.camisaEscura, -12, -27 + passo * 2, 3, 13);
    R(COR.camisaEscura, 9, -27 - passo * 2, 3, 13);

    R(COR.pele, -12, -14 + passo * 2, 3, 3);
    R(COR.pele, 9, -14 - passo * 2, 3, 3);

    // Tronco e crachá.
    R(COR.camisa, -9, -28, 18, 16);
    R(COR.cracha, 3, -23, 4, 4);

    // Cabeça.
    R(COR.pele, -7, -40, 14, 12);
    R(COR.cabelo, -8, -42, 16, 5);
    R(COR.cabelo, -8, -42, 3, 9);
    R(COR.cabelo, 5, -42, 3, 9);

    R(COR.olho, -4, -35, 2, 3);
    R(COR.olho, 2, -35, 2, 3);
}

function desenharCostas(passo, sobe) {
    desenharPernasFrenteCostas(passo);

    ctx.translate(0, sobe);

    R(COR.camisaEscura, -12, -27 - passo * 2, 3, 13);
    R(COR.camisaEscura, 9, -27 + passo * 2, 3, 13);

    R(COR.pele, -12, -14 - passo * 2, 3, 3);
    R(COR.pele, 9, -14 + passo * 2, 3, 3);

    R(COR.camisa, -9, -28, 18, 16);
    R(COR.camisaEscura, -1, -28, 2, 16);

    // Cabeça vista de costas.
    R(COR.cabelo, -8, -42, 16, 14);
}

function desenharLado(passo, sobe) {
    // Pernas.
    R(COR.calcaEscura, -3 - passo * 4, -14, 6, 14);
    R(COR.sapato, -3 - passo * 4, -3, 8, 3);

    R(COR.calca, -3 + passo * 4, -14, 6, 14);
    R(COR.sapato, -3 + passo * 4, -3, 8, 3);

    ctx.translate(0, sobe);

    // Tronco e braço.
    R(COR.camisa, -6, -28, 12, 16);
    R(COR.camisaEscura, -2 - passo * 3, -27, 4, 13);
    R(COR.pele, -2 - passo * 3, -14, 4, 3);

    // Cabeça virada para o lado.
    R(COR.pele, -6, -40, 12, 12);
    R(COR.pele, 6, -33, 2, 3);

    R(COR.cabelo, -7, -42, 14, 5);
    R(COR.cabelo, -7, -42, 6, 12);

    R(COR.olho, 3, -35, 2, 3);
}