// ================================================================
//  Personagem — anda nas 4 direções, colide com os objetos da sala
//  (desenhado com retângulos, igual ao resto da sala: sem imagens)
// ================================================================

// x, y = posição dos PÉS do personagem
// h: 0 faz o personagem entrar na ordem de desenho (quem está mais embaixo fica por cima)
const jogador = {
  tipo: 'jogador',
  x: 480,
  y: 540,
  h: 0,
  vel: 2.4,        // velocidade (pixels por quadro a 60 fps)
  dir: 'baixo',    // 'baixo' | 'cima' | 'esquerda' | 'direita'
  andando: false,
  frame: 0,        // 0 a 3 (ciclo da caminhada)
  tempo: 0
};

const PES = { w: 20, h: 10 };                       // caixa de colisão nos pés
const LIMITE = { x1: 24, x2: 936, y1: 96, y2: 616 }; // área de chão livre
const SEM_COLISAO = ['caderno'];                    // objetos que ficam em cima de outros

// ---------------------------------------------------------------
//  Teclado
// ---------------------------------------------------------------
const teclas = {};

addEventListener('keydown', e => {
  const tecla = e.key.toLowerCase();
  if (tecla.startsWith('arrow')) e.preventDefault(); // setas não rolam a página
  teclas[tecla] = true;
});

addEventListener('keyup', e => {
  teclas[e.key.toLowerCase()] = false;
});

addEventListener('blur', () => {
  for (const tecla in teclas) teclas[tecla] = false; // evita "tecla presa" ao trocar de aba
});

// ---------------------------------------------------------------
//  Colisão
// ---------------------------------------------------------------
function sobrepoe(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x &&
         a.y < b.y + b.h && a.y + a.h > b.y;
}

function bateu(x, y) {
  const pes = { x: x - PES.w / 2, y: y - PES.h, w: PES.w, h: PES.h };

  if (pes.x < LIMITE.x1 || pes.x + pes.w > LIMITE.x2) return true;
  if (pes.y < LIMITE.y1 || y > LIMITE.y2) return true;

  return OBJETOS.some(o =>
    !o.parede && !SEM_COLISAO.includes(o.tipo) && sobrepoe(pes, o)
  );
}

// Move um eixo de cada vez: assim o personagem desliza pelas paredes
function mover(dx, dy) {
  if (!bateu(jogador.x + dx, jogador.y)) jogador.x += dx;
  if (!bateu(jogador.x, jogador.y + dy)) jogador.y += dy;
}

// ---------------------------------------------------------------
//  Atualização (chamada a cada quadro)
// ---------------------------------------------------------------
let ultimoTempo = 0;

function atualizarJogador(t) {
  // dt = 1 em 60 fps; mantém a mesma velocidade em telas de 120 Hz, etc.
  const dt = ultimoTempo ? Math.min((t - ultimoTempo) / 16.667, 3) : 1;
  ultimoTempo = t;

  let dx = 0;
  let dy = 0;
  if (teclas['arrowleft']  || teclas['a']) dx -= 1;
  if (teclas['arrowright'] || teclas['d']) dx += 1;
  if (teclas['arrowup']    || teclas['w']) dy -= 1;
  if (teclas['arrowdown']  || teclas['s']) dy += 1;

  jogador.andando = dx !== 0 || dy !== 0;

  if (!jogador.andando) {
    jogador.frame = 0;
    jogador.tempo = 0;
    return;
  }

  // Direção do desenho
  if (dx < 0) jogador.dir = 'esquerda';
  else if (dx > 0) jogador.dir = 'direita';
  else if (dy < 0) jogador.dir = 'cima';
  else jogador.dir = 'baixo';

  // Divide pela norma para não andar mais rápido na diagonal
  const norma = Math.hypot(dx, dy);
  const passo = jogador.vel * dt;
  mover((dx / norma) * passo, (dy / norma) * passo);

  // Animação: troca de quadro a cada 7 ciclos
  jogador.tempo += dt;
  jogador.frame = Math.floor(jogador.tempo / 7) % 4;
}

// ---------------------------------------------------------------
//  Desenho
//  A origem (0, 0) fica nos pés; o corpo cresce para cima (y negativo)
// ---------------------------------------------------------------
const COR = {
  pele: '#e0b48c',
  cabelo: '#2b1d14',
  camisa: '#3b6ea5',
  camisaEscura: '#2f5885',
  calca: '#2a2f3a',
  calcaEscura: '#1f232c',
  sapato: '#14171c',
  olho: '#111111',
  cracha: '#e8e2d0'
};

function desenharJogador(j) {
  // passo: -1, 0 ou 1 (posição das pernas); sobe: o corpo sobe 1px a cada passo
  const passo = j.andando ? [0, 1, 0, -1][j.frame] : 0;
  const sobe = passo !== 0 ? -1 : 0;

  ctx.save();
  ctx.translate(Math.round(j.x), Math.round(j.y));

  // Sombra
  ctx.fillStyle = 'rgba(0,0,0,.25)';
  ctx.beginPath();
  ctx.ellipse(0, -1, 11, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  // Esquerda = lado direito espelhado
  if (j.dir === 'esquerda') ctx.scale(-1, 1);

  if (j.dir === 'baixo') desenharFrente(passo, sobe);
  else if (j.dir === 'cima') desenharCostas(passo, sobe);
  else desenharLado(passo, sobe);

  ctx.restore();
}

function desenharPernasFrenteCostas(passo) {
  const levantaE = passo > 0 ? 3 : 0;
  const levantaD = passo < 0 ? 3 : 0;
  R(COR.calca, -7, -14, 6, 14 - levantaE);
  R(COR.calca, 1, -14, 6, 14 - levantaD);
  R(COR.sapato, -7, -3 - levantaE, 6, 3);
  R(COR.sapato, 1, -3 - levantaD, 6, 3);
}

function desenharFrente(passo, sobe) {
  desenharPernasFrenteCostas(passo);

  ctx.translate(0, sobe);
  // Braços (balançam ao contrário das pernas)
  R(COR.camisaEscura, -12, -27 + passo * 2, 3, 13);
  R(COR.camisaEscura, 9, -27 - passo * 2, 3, 13);
  R(COR.pele, -12, -14 + passo * 2, 3, 3);
  R(COR.pele, 9, -14 - passo * 2, 3, 3);
  // Tronco e crachá
  R(COR.camisa, -9, -28, 18, 16);
  R(COR.cracha, 3, -23, 4, 4);
  // Cabeça
  R(COR.pele, -7, -40, 14, 12);
  R(COR.cabelo, -8, -42, 16, 5);
  R(COR.cabelo, -8, -42, 3, 9);
  R(COR.cabelo, 5, -42, 3, 9);
  R(COR.olho, -4, -35, 2, 3);
  R(COR.olho, 2, -35, 2, 3);
}

function desenharCostas(passo, sobe) {
  desenharPernasFrenteCostas(passo);

  ctx.translate(0, sobe);
  R(COR.camisaEscura, -12, -27 - passo * 2, 3, 13);
  R(COR.camisaEscura, 9, -27 + passo * 2, 3, 13);
  R(COR.pele, -12, -14 - passo * 2, 3, 3);
  R(COR.pele, 9, -14 + passo * 2, 3, 3);
  R(COR.camisa, -9, -28, 18, 16);
  R(COR.camisaEscura, -1, -28, 2, 16); // costura
  // Cabeça (só cabelo, de costas)
  R(COR.cabelo, -8, -42, 16, 14);
}

function desenharLado(passo, sobe) {
  // Perna de trás (mais escura) e da frente
  R(COR.calcaEscura, -3 - passo * 4, -14, 6, 14);
  R(COR.sapato, -3 - passo * 4, -3, 8, 3);
  R(COR.calca, -3 + passo * 4, -14, 6, 14);
  R(COR.sapato, -3 + passo * 4, -3, 8, 3);

  ctx.translate(0, sobe);
  // Tronco, braço e crachá
  R(COR.camisa, -6, -28, 12, 16);
  R(COR.camisaEscura, -2 - passo * 3, -27, 4, 13);
  R(COR.pele, -2 - passo * 3, -14, 4, 3);
  // Cabeça virada para a direita
  R(COR.pele, -6, -40, 12, 12);
  R(COR.pele, 6, -33, 2, 3); // nariz
  R(COR.cabelo, -7, -42, 14, 5);
  R(COR.cabelo, -7, -42, 6, 12);
  R(COR.olho, 3, -35, 2, 3);
}