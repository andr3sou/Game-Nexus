const menuInicial = document.getElementById("menuInicial");
const telaNome = document.getElementById("telaNome");

const btnIniciar = document.getElementById("btnIniciar");
const btnVoltar = document.getElementById("btnVoltar");
const formNome = document.getElementById("formNome");
const campoNome = document.getElementById("nomeJogador");

// Ao clicar em INICIAR, mostra a tela para digitar o nome.
btnIniciar.addEventListener("click", function () {
    menuInicial.classList.add("oculto");
    telaNome.classList.remove("oculto");

    campoNome.focus();
});

// Ao clicar em VOLTAR, retorna ao menu inicial.
btnVoltar.addEventListener("click", function () {
    telaNome.classList.add("oculto");
    menuInicial.classList.remove("oculto");

    campoNome.value = "";
});

// Ao enviar o formulário, salva o nome e redireciona para a página da sala.
formNome.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const nomeJogadorAtual = campoNome.value.trim();

    if (nomeJogadorAtual === "") {
        alert("Digite seu nome para começar!");
        campoNome.focus();
        return;
    }

    localStorage.setItem("nomeJogador", nomeJogadorAtual);

    // Redireciona para o arquivo sala.html
    window.location.href = "./sala.html";
});