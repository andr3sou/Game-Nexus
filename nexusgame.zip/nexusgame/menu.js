const menuInicial = document.getElementById("menuInicial");
const telaNome = document.getElementById("telaNome");

const btnIniciar = document.getElementById("btnIniciar");
const btnVoltar = document.getElementById("btnVoltar");

const formNome = document.getElementById("formNome");
const campoNome = document.getElementById("nomeJogador");

// Abre a tela para informar o nome.
btnIniciar.addEventListener("click", function () {
    menuInicial.classList.add("oculto");
    telaNome.classList.remove("oculto");

    campoNome.focus();
});

// Volta para o menu inicial.
btnVoltar.addEventListener("click", function () {
    telaNome.classList.add("oculto");
    menuInicial.classList.remove("oculto");

    campoNome.value = "";
});

// Salva o nome e abre a sala.
formNome.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const nomeJogador = campoNome.value.trim();

    if (nomeJogador === "") {
        alert("Digite o nome do jogador.");
        campoNome.focus();
        return;
    }

    // Guarda o nome para poder utilizá-lo na sala.
    localStorage.setItem("nomeJogador", nomeJogador);

    // Abre a página do jogo.
    window.location.href = "sala.html";
});