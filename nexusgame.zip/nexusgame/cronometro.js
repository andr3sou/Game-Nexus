// ================================================================
// PROTOCOLO NEXUS — CRONÔMETRO DA SALA
// ================================================================

const TEMPO_INICIAL = 5 * 60;
let tempoRestante = TEMPO_INICIAL;
let intervaloCronometro = null;

window.jogoEncerrado = false;
window.portaDigitando = false;

function formatarTempo(segundos) {
    const minutos = Math.floor(segundos / 60);
    const resto = segundos % 60;
    return String(minutos).padStart(2, "0") + ":" +
           String(resto).padStart(2, "0");
}

function atualizarCronometro() {
    const cronometro = document.getElementById("cronometro");
    if (!cronometro || window.jogoEncerrado) return;

    cronometro.textContent = formatarTempo(tempoRestante);

    if (tempoRestante <= 60 && tempoRestante > 0) {
        cronometro.classList.add("tempoCritico");
    }

    if (tempoRestante <= 0) {
        encerrarJogo();
        return;
    }

    tempoRestante--;
}

function pararCronometro() {
    if (intervaloCronometro !== null) {
        clearInterval(intervaloCronometro);
        intervaloCronometro = null;
    }
}

function encerrarJogo() {
    if (window.jogoEncerrado) return;

    window.jogoEncerrado = true;
    window.portaDigitando = false;
    pararCronometro();

    const cronometro = document.getElementById("cronometro");
    if (cronometro) {
        cronometro.textContent = "00:00";
        cronometro.classList.add("tempoCritico");
    }

    const telaFim = document.getElementById("telaFim");
    if (telaFim) telaFim.style.display = "flex";
}

document.addEventListener("DOMContentLoaded", function () {
    atualizarCronometro();

    if (!window.jogoEncerrado) {
        intervaloCronometro = setInterval(atualizarCronometro, 1000);
    }
});
