// ================================================================
// PROTOCOLO NEXUS — INTERAÇÃO COM A PORTA
// Código correto: ABRIR
// ================================================================

(function () {
    let pertoDaPorta = false;
    let janelaCodigo = null;
    let avisoPorta = null;

    function criarEstilos() {
        if (document.getElementById("estilosPorta")) return;

        const estilo = document.createElement("style");
        estilo.id = "estilosPorta";
        estilo.textContent = `
            #avisoPorta {
                position: fixed;
                left: 50%;
                bottom: 28px;
                transform: translateX(-50%);
                z-index: 1500;
                max-width: 90vw;
                padding: 13px 20px;
                border: 1px solid #00ffcc;
                border-radius: 8px;
                background: rgba(5, 10, 16, .95);
                color: #00ffcc;
                font: bold 16px Arial, sans-serif;
                text-align: center;
                box-shadow: 0 0 18px rgba(0,255,204,.2);
            }
            #janelaCodigoPorta {
                position: fixed;
                inset: 0;
                z-index: 3000;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                background: rgba(0,0,0,.88);
                font-family: Arial, sans-serif;
            }
            #caixaCodigoPorta {
                width: min(420px, 100%);
                padding: 28px;
                border: 2px solid #00ffcc;
                border-radius: 12px;
                background: #151923;
                text-align: center;
                box-shadow: 0 0 30px rgba(0,255,204,.2);
            }
            #caixaCodigoPorta h2 { color: #00ffcc; margin-top: 0; }
            #entradaCodigoPorta {
                width: 100%;
                padding: 13px;
                margin: 12px 0;
                border: 1px solid #00ffcc;
                border-radius: 6px;
                background: #080b10;
                color: white;
                font-size: 20px;
                text-align: center;
                text-transform: uppercase;
            }
            .botaoPorta {
                padding: 11px 18px;
                margin: 6px 3px 0;
                border: 0;
                border-radius: 6px;
                background: #00b894;
                color: #06110f;
                font-weight: bold;
                cursor: pointer;
            }
            .botaoPorta.cancelar { background: #363b50; color: white; }
            #erroCodigoPorta { min-height: 22px; color: #ff5c5c; }
            #telaVitoriaNexus {
                position: fixed;
                inset: 0;
                z-index: 4000;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                background: rgba(0,0,0,.96);
                color: white;
                text-align: center;
                font-family: Arial, sans-serif;
            }
            #caixaVitoriaNexus {
                width: min(760px, 100%);
                padding: 32px 24px;
                border: 2px solid #00ffcc;
                border-radius: 14px;
                background: #101923;
                box-shadow: 0 0 35px rgba(0,255,204,.25);
            }
            #caixaVitoriaNexus h1 {
                color: #00ffcc;
                font-size: clamp(28px, 5vw, 44px);
            }
            #caixaVitoriaNexus p {
                font-size: clamp(18px, 3vw, 24px);
                line-height: 1.5;
            }
            #btnJogarNovamenteNexus {
                margin-top: 15px;
                padding: 14px 24px;
                border: 0;
                border-radius: 7px;
                background: #00b894;
                color: #07120f;
                font-weight: bold;
                font-size: 16px;
                cursor: pointer;
            }
        `;
        document.head.appendChild(estilo);
    }

    function encontrarPorta() {
        if (typeof OBJETOS === "undefined") return null;
        return OBJETOS.find(obj => obj.tipo === "porta") || null;
    }

    function jogadorPerto() {
        if (typeof jogador === "undefined") return false;
        const porta = encontrarPorta();
        if (!porta) return false;

        // O personagem é posicionado pelos pés; a interação fica na base da porta.
        const centroX = porta.x + porta.w / 2;
        const baseY = porta.y + porta.h;
        return Math.hypot(jogador.x - centroX, jogador.y - baseY) <= 82;
    }

    function mostrarAviso() {
        if (!avisoPorta) {
            avisoPorta = document.createElement("div");
            avisoPorta.id = "avisoPorta";
            avisoPorta.textContent = "Pressione R para interagir com a porta";
            document.body.appendChild(avisoPorta);
        }
    }

    function esconderAviso() {
        if (avisoPorta) {
            avisoPorta.remove();
            avisoPorta = null;
        }
    }

    function abrirJanelaCodigo() {
        if (window.jogoEncerrado || janelaCodigo) return;

        window.portaDigitando = true;
        esconderAviso();

        janelaCodigo = document.createElement("div");
        janelaCodigo.id = "janelaCodigoPorta";
        janelaCodigo.innerHTML = `
            <form id="caixaCodigoPorta">
                <h2>PORTA BLOQUEADA</h2>
                <p>Digite o código para sair da sala.</p>
                <input id="entradaCodigoPorta" type="text"
                    maxlength="20" autocomplete="off"
                    placeholder="Digite o código" aria-label="Código da porta">
                <div id="erroCodigoPorta" role="status"></div>
                <button class="botaoPorta" type="submit">CONFIRMAR</button>
                <button class="botaoPorta cancelar" id="cancelarCodigoPorta" type="button">CANCELAR</button>
            </form>
        `;
        document.body.appendChild(janelaCodigo);

        const formulario = document.getElementById("caixaCodigoPorta");
        const entrada = document.getElementById("entradaCodigoPorta");
        const erro = document.getElementById("erroCodigoPorta");

        entrada.focus();

        entrada.addEventListener("input", function () {
            if (typeof Som !== "undefined" && Som.digitar) Som.digitar();
        });

        formulario.addEventListener("submit", function (evento) {
            evento.preventDefault();

            if (entrada.value.trim().toUpperCase() === "ABRIR") {
                if (typeof Som !== "undefined" && Som.acerto) Som.acerto();
                vencerJogo();
            } else {
                erro.textContent = "Código incorreto. Tente novamente.";
                entrada.select();
                if (typeof Som !== "undefined" && Som.erro) Som.erro();
            }
        });

        document.getElementById("cancelarCodigoPorta").addEventListener("click", fecharJanelaCodigo);
    }

    function fecharJanelaCodigo() {
        if (janelaCodigo) {
            janelaCodigo.remove();
            janelaCodigo = null;
        }
        window.portaDigitando = false;
        if (pertoDaPorta && !window.jogoEncerrado) mostrarAviso();
    }

    function formatarDuracao(segundos) {
        const minutos = Math.floor(segundos / 60);
        const resto = segundos % 60;
        return String(minutos).padStart(2, "0") + ":" + String(resto).padStart(2, "0");
    }

    function vencerJogo() {
        if (window.jogoEncerrado) return;

        const tempoGasto = Math.max(0, TEMPO_INICIAL - tempoRestante - 1);
        window.jogoEncerrado = true;
        window.portaDigitando = false;

        if (typeof pararCronometro === "function") pararCronometro();
        if (janelaCodigo) {
            janelaCodigo.remove();
            janelaCodigo = null;
        }
        esconderAviso();

        if (typeof Som !== "undefined" && Som.desligar) Som.desligar();

        const tela = document.createElement("div");
        tela.id = "telaVitoriaNexus";
        tela.innerHTML = `
            <div id="caixaVitoriaNexus">
                <h1>PARABÉNS!</h1>
                <p>VC CONSEGUIU DESLIGAR NEXUS E SAIR DA SALA.</p>
                <p>SEU TEMPO FOI: <strong>${formatarDuracao(tempoGasto)}</strong></p>
                <button id="btnJogarNovamenteNexus" type="button">JOGAR NOVAMENTE</button>
            </div>
        `;
        document.body.appendChild(tela);
        document.getElementById("btnJogarNovamenteNexus").addEventListener("click", function () {
            window.location.href = "index.html";
        });
    }

    document.addEventListener("keydown", function (evento) {
        if (evento.key.toLowerCase() === "r" && pertoDaPorta &&
            !window.jogoEncerrado && !window.portaDigitando) {
            evento.preventDefault();
            abrirJanelaCodigo();
        }

        if (evento.key === "Escape" && janelaCodigo) {
            fecharJanelaCodigo();
        }
    });

    function verificarProximidade() {
        if (window.jogoEncerrado || window.portaDigitando) return;
        pertoDaPorta = jogadorPerto();

        if (pertoDaPorta) {
            mostrarAviso();
        } else {
            esconderAviso();
        }
    }

    document.addEventListener("DOMContentLoaded", function () {
        criarEstilos();
        setInterval(verificarProximidade, 100);
    });
})();
